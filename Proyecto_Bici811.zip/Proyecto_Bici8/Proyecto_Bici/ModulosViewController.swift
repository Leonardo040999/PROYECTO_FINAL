//
//  ModulosViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class ModulosViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    

    var modules = [modulos]()
    var myindex = 0
    

    @IBOutlet weak var mapa: MKMapView!
    @IBOutlet weak var tabla: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        modules.append(modulos(nombre: "Universidad", latitude: 19.325203, longitude: -99.174788))
        modules.append(modulos(nombre: "Facultad de Ciencias", latitude: 19.325146, longitude: -99.178884))
        modules.append(modulos(nombre: "Anexo de Ingeniería", latitude: 19.327874, longitude: -99.182928))
        modules.append(modulos(nombre: "Facultad de Ingeniería", latitude: 19.332143, longitude: -99.184406))
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modules.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = modules[indexPath.row].nombre
        
        
        return cell
    }
        @IBAction func unwindSecondView(segue: UIStoryboardSegue){
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SecondView"{
            
            let indexPath = tabla.indexPathForSelectedRow
            let destination = segue.destination as! MapViewController
            
            destination.FromFirstView = modules[(indexPath?.row)!].nombre
            destination.FromFirstView2 = modules[(indexPath?.row)!].latitude
            destination.FromFirstView3 = modules[(indexPath?.row)!].longitude
    
    
        }}
            
}
            

