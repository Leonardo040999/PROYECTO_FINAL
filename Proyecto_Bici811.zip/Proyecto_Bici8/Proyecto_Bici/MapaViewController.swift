//
//  MapaViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/22/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class MapaViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    

    @IBOutlet weak var mapas: MKMapView!
    let locationManager = CLLocationManager()
    @IBOutlet weak var Modules: UILabel!
    var fromFirstView : String = ""
    override func viewDidLoad() {
        
       
        super.viewDidLoad()
        Modules.text = fromFirstView
        
        mapas.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapas.showsUserLocation = true

    }
    
    

   
}
