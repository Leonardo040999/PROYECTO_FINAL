//
//  ViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {
    
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toLoginVC"{
            
            let destino = segue.destination as! LoginViewController
            destino.username = Email.text!
        }
    }
    
    
    @IBAction func Perfil(_ sender: UIButton) {
        guard let correo = Email.text,
            let pass = Password.text else { return }
        
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                self.performSegue(withIdentifier: "toLoginVC", sender: nil )
            }
        }
        
    }
}


